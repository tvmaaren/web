void drawframe(float x_pos, float y_pos, float kart_angle, float scale, int screen_width, 
		int screen_height, TRACK_DATA* track,
		/*Only used if camera is set to be relative to the track*/float track_angle,
		CONFIG* config);
