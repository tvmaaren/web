void play_ghost(ALLEGRO_FS_ENTRY *ghost_file_entry, ALLEGRO_FS_ENTRY *track_entry, 
		CONFIG* config, ALLEGRO_DISPLAY* disp);
