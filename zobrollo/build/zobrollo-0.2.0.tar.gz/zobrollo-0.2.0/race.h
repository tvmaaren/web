void race(ALLEGRO_FS_ENTRY *track_file_entry, char* filename, CONFIG* config, 
		ALLEGRO_DISPLAY* disp);
// vim: cc=100
