void add_element(void** list, int *required, int *available, size_t element_size);
void must_init(bool test, const char *description);
char* get_filename(ALLEGRO_FS_ENTRY *e);

// vim: cc=100
