void add_element(void** list, int *required, int *available, size_t element_size);
void must_init(bool test, const char *description);
